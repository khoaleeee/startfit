from django.contrib import admin

from authapp.models import Contact


# Register your models here.
admin.site.register(Contact)